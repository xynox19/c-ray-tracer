cmake_minimum_required(VERSION 3.16)
project(raytracer LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)   # ray tracing is painfully slow without optimisation
endif()

find_package(Threads REQUIRED)

add_executable(raytracer src/main.cpp)
target_link_libraries(raytracer PRIVATE Threads::Threads)

if(MSVC)
  target_compile_options(raytracer PRIVATE /W4)
else()
  target_compile_options(raytracer PRIVATE -Wall -Wextra -Wpedantic)
endif()
