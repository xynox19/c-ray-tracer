#pragma once
#include <memory>
#include <vector>
#include "hittable.h"

// A scene: a list of objects. Returns the closest hit among all of them.
class HittableList : public Hittable {
public:
    void add(std::shared_ptr<Hittable> obj) { objects_.push_back(std::move(obj)); }

    bool hit(const Ray& r, double t_min, double t_max, HitRecord& rec) const override {
        HitRecord tmp;
        bool hit_any = false;
        double closest = t_max;
        for (const auto& obj : objects_) {
            if (obj->hit(r, t_min, closest, tmp)) {
                hit_any = true;
                closest = tmp.t;   // shrink the search range so farther hits are ignored
                rec = tmp;
            }
        }
        return hit_any;
    }

private:
    std::vector<std::shared_ptr<Hittable>> objects_;
};
