#pragma once
#include "vec3.h"

// A ray is a half-line: P(t) = origin + t * direction, for t > 0.
class Ray {
public:
    Ray() = default;
    Ray(const Point3& origin, const Vec3& direction) : orig_(origin), dir_(direction) {}

    const Point3& origin() const { return orig_; }
    const Vec3& direction() const { return dir_; }
    Point3 at(double t) const { return orig_ + t * dir_; }

private:
    Point3 orig_;
    Vec3 dir_;
};
