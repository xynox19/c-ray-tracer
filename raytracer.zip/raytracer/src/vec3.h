#pragma once
// Vec3: a 3D vector used for points, directions AND colours.
#include <cmath>

struct Vec3 {
    double x{}, y{}, z{};

    constexpr Vec3() = default;
    constexpr Vec3(double x, double y, double z) : x(x), y(y), z(z) {}

    constexpr Vec3 operator-() const { return {-x, -y, -z}; }
    constexpr Vec3& operator+=(const Vec3& v) { x += v.x; y += v.y; z += v.z; return *this; }
    constexpr Vec3& operator*=(double t) { x *= t; y *= t; z *= t; return *this; }
    constexpr Vec3& operator/=(double t) { return *this *= (1.0 / t); }

    constexpr double length_squared() const { return x * x + y * y + z * z; }
    double length() const { return std::sqrt(length_squared()); }

    // True if the vector is almost exactly zero in every component.
    bool near_zero() const {
        constexpr double s = 1e-8;
        return std::fabs(x) < s && std::fabs(y) < s && std::fabs(z) < s;
    }
};

// Aliases make intent obvious at the call site.
using Point3 = Vec3;
using Color  = Vec3;

constexpr Vec3 operator+(const Vec3& a, const Vec3& b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
constexpr Vec3 operator-(const Vec3& a, const Vec3& b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
constexpr Vec3 operator*(const Vec3& a, const Vec3& b) { return {a.x * b.x, a.y * b.y, a.z * b.z}; } // component-wise
constexpr Vec3 operator*(double t, const Vec3& v)      { return {t * v.x, t * v.y, t * v.z}; }
constexpr Vec3 operator*(const Vec3& v, double t)      { return t * v; }
constexpr Vec3 operator/(const Vec3& v, double t)      { return (1.0 / t) * v; }

constexpr double dot(const Vec3& a, const Vec3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }

constexpr Vec3 cross(const Vec3& a, const Vec3& b) {
    return {a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x};
}

inline Vec3 unit_vector(const Vec3& v) { return v / v.length(); }
