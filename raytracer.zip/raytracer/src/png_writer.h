#pragma once
// Minimal dependency-free PNG writer (uncompressed "stored" deflate blocks).
// Files are bigger than a normal PNG but open everywhere.
#include <array>
#include <cstdint>
#include <fstream>
#include <string>
#include <vector>

namespace png {

inline void put32(std::vector<std::uint8_t>& v, std::uint32_t x) {
    for (int i = 3; i >= 0; --i) v.push_back(static_cast<std::uint8_t>((x >> (8 * i)) & 0xFF));
}

inline std::uint32_t crc32(const std::uint8_t* d, std::size_t n) {
    static const auto table = [] {
        std::array<std::uint32_t, 256> t{};
        for (std::uint32_t i = 0; i < 256; ++i) {
            std::uint32_t c = i;
            for (int k = 0; k < 8; ++k) c = (c & 1) ? 0xEDB88320u ^ (c >> 1) : c >> 1;
            t[i] = c;
        }
        return t;
    }();
    std::uint32_t crc = 0xFFFFFFFFu;
    for (std::size_t i = 0; i < n; ++i) crc = table[(crc ^ d[i]) & 0xFF] ^ (crc >> 8);
    return crc ^ 0xFFFFFFFFu;
}

inline void write_chunk(std::ofstream& out, const char type[4], const std::vector<std::uint8_t>& data) {
    std::vector<std::uint8_t> chunk;
    put32(chunk, static_cast<std::uint32_t>(data.size()));
    chunk.insert(chunk.end(), type, type + 4);
    chunk.insert(chunk.end(), data.begin(), data.end());
    // CRC covers the type + data (everything after the 4-byte length).
    put32(chunk, crc32(chunk.data() + 4, chunk.size() - 4));
    out.write(reinterpret_cast<const char*>(chunk.data()), static_cast<std::streamsize>(chunk.size()));
}

// rgb: width*height*3 bytes, row-major, top row first.
inline bool write(const std::string& path, int width, int height, const std::vector<std::uint8_t>& rgb) {
    std::ofstream out(path, std::ios::binary);
    if (!out) return false;

    const unsigned char sig[8] = {0x89, 'P', 'N', 'G', '\r', '\n', 0x1A, '\n'};
    out.write(reinterpret_cast<const char*>(sig), 8);

    std::vector<std::uint8_t> ihdr;
    put32(ihdr, static_cast<std::uint32_t>(width));
    put32(ihdr, static_cast<std::uint32_t>(height));
    ihdr.insert(ihdr.end(), {8, 2, 0, 0, 0});   // 8-bit, RGB, no interlace
    write_chunk(out, "IHDR", ihdr);

    // Raw scanlines: each row is prefixed with filter byte 0.
    std::vector<std::uint8_t> raw;
    raw.reserve(static_cast<std::size_t>(height) * (width * 3 + 1));
    for (int y = 0; y < height; ++y) {
        raw.push_back(0);
        auto first = rgb.begin() + static_cast<std::ptrdiff_t>(y) * width * 3;
        raw.insert(raw.end(), first, first + width * 3);
    }

    // zlib stream = header + stored deflate blocks (<= 65535 bytes each) + Adler-32.
    std::vector<std::uint8_t> z{0x78, 0x01};
    for (std::size_t pos = 0; pos < raw.size();) {
        std::size_t len = std::min<std::size_t>(65535, raw.size() - pos);
        bool last = (pos + len == raw.size());
        z.push_back(last ? 1 : 0);
        z.push_back(len & 0xFF);          z.push_back((len >> 8) & 0xFF);
        z.push_back(~len & 0xFF);         z.push_back((~len >> 8) & 0xFF);
        z.insert(z.end(), raw.begin() + pos, raw.begin() + pos + len);
        pos += len;
    }
    std::uint32_t a = 1, b = 0;
    for (std::uint8_t byte : raw) { a = (a + byte) % 65521; b = (b + a) % 65521; }
    put32(z, (b << 16) | a);

    write_chunk(out, "IDAT", z);
    write_chunk(out, "IEND", {});
    return static_cast<bool>(out);
}

}  // namespace png
