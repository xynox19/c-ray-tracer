#pragma once
// Thread-safe random helpers. Each thread owns its own generator, so no locking is needed.
#include <atomic>
#include <random>
#include "vec3.h"

inline std::mt19937& rng() {
    static std::atomic<unsigned> seed_counter{1337};
    // thread_local: one generator per thread, seeded differently.
    thread_local std::mt19937 gen(seed_counter.fetch_add(1));
    return gen;
}

inline double random_double() {                       // [0, 1)
    thread_local std::uniform_real_distribution<double> dist(0.0, 1.0);
    return dist(rng());
}

inline double random_double(double lo, double hi) { return lo + (hi - lo) * random_double(); }

inline Vec3 random_vec(double lo, double hi) {
    return {random_double(lo, hi), random_double(lo, hi), random_double(lo, hi)};
}

// Rejection sampling: pick random points in a cube until one lands inside the unit sphere.
inline Vec3 random_in_unit_sphere() {
    while (true) {
        Vec3 p = random_vec(-1, 1);
        if (p.length_squared() < 1.0) return p;
    }
}

inline Vec3 random_unit_vector() { return unit_vector(random_in_unit_sphere()); }

// Random point in the unit disk (used for depth-of-field lens sampling).
inline Vec3 random_in_unit_disk() {
    while (true) {
        Vec3 p{random_double(-1, 1), random_double(-1, 1), 0};
        if (p.length_squared() < 1.0) return p;
    }
}
