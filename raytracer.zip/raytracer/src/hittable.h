#pragma once
#include "ray.h"

class Material;  // forward declaration: avoids a circular include with material.h

// Everything we need to know about a ray/surface intersection.
struct HitRecord {
    Point3 point;
    Vec3 normal;                    // always points AGAINST the incoming ray
    const Material* material = nullptr;
    double t = 0;                   // ray parameter at the hit
    bool front_face = true;         // did we hit the outside of the surface?

    void set_face_normal(const Ray& r, const Vec3& outward_normal) {
        front_face = dot(r.direction(), outward_normal) < 0;
        normal = front_face ? outward_normal : -outward_normal;
    }
};

// Interface for anything a ray can hit.
class Hittable {
public:
    virtual ~Hittable() = default;
    virtual bool hit(const Ray& r, double t_min, double t_max, HitRecord& rec) const = 0;
};
