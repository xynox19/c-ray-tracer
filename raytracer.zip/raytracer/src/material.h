#pragma once
#include <algorithm>
#include <cmath>
#include "hittable.h"
#include "random.h"

// A material decides how a ray bounces (scatters) off a surface.
class Material {
public:
    virtual ~Material() = default;
    // Returns false if the ray is absorbed.
    virtual bool scatter(const Ray& in, const HitRecord& rec,
                         Color& attenuation, Ray& scattered) const = 0;
};

// Matte surface: scatters light in a random direction around the normal.
class Lambertian : public Material {
public:
    explicit Lambertian(const Color& albedo) : albedo_(albedo) {}

    bool scatter(const Ray&, const HitRecord& rec, Color& attenuation, Ray& scattered) const override {
        Vec3 dir = rec.normal + random_unit_vector();   // cosine-weighted distribution
        if (dir.near_zero()) dir = rec.normal;          // guard against a degenerate direction
        scattered = Ray(rec.point, dir);
        attenuation = albedo_;
        return true;
    }

private:
    Color albedo_;
};

inline Vec3 reflect(const Vec3& v, const Vec3& n) { return v - 2 * dot(v, n) * n; }

// Mirror-like surface; fuzz > 0 blurs the reflection.
class Metal : public Material {
public:
    Metal(const Color& albedo, double fuzz) : albedo_(albedo), fuzz_(std::clamp(fuzz, 0.0, 1.0)) {}

    bool scatter(const Ray& in, const HitRecord& rec, Color& attenuation, Ray& scattered) const override {
        Vec3 reflected = reflect(unit_vector(in.direction()), rec.normal);
        scattered = Ray(rec.point, reflected + fuzz_ * random_in_unit_sphere());
        attenuation = albedo_;
        return dot(scattered.direction(), rec.normal) > 0;   // absorb rays pushed below the surface
    }

private:
    Color albedo_;
    double fuzz_;
};

// Glass / water: refracts or reflects depending on angle (Snell's law + Schlick).
class Dielectric : public Material {
public:
    explicit Dielectric(double refraction_index) : ir_(refraction_index) {}

    bool scatter(const Ray& in, const HitRecord& rec, Color& attenuation, Ray& scattered) const override {
        attenuation = Color(1, 1, 1);   // glass absorbs nothing
        double ratio = rec.front_face ? (1.0 / ir_) : ir_;

        Vec3 unit_dir = unit_vector(in.direction());
        double cos_theta = std::min(dot(-unit_dir, rec.normal), 1.0);
        double sin_theta = std::sqrt(1.0 - cos_theta * cos_theta);

        bool cannot_refract = ratio * sin_theta > 1.0;   // total internal reflection
        Vec3 dir = (cannot_refract || reflectance(cos_theta, ratio) > random_double())
                       ? reflect(unit_dir, rec.normal)
                       : refract(unit_dir, rec.normal, ratio);

        scattered = Ray(rec.point, dir);
        return true;
    }

private:
    static Vec3 refract(const Vec3& uv, const Vec3& n, double etai_over_etat) {
        double cos_theta = std::min(dot(-uv, n), 1.0);
        Vec3 r_perp = etai_over_etat * (uv + cos_theta * n);
        Vec3 r_parallel = -std::sqrt(std::fabs(1.0 - r_perp.length_squared())) * n;
        return r_perp + r_parallel;
    }

    // Schlick's approximation: glass is more mirror-like at grazing angles.
    static double reflectance(double cosine, double ratio) {
        double r0 = (1 - ratio) / (1 + ratio);
        r0 *= r0;
        return r0 + (1 - r0) * std::pow(1 - cosine, 5);
    }

    double ir_;
};
