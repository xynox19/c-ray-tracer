#pragma once
#include <cmath>
#include <numbers>
#include "random.h"
#include "ray.h"

// A positionable camera with field of view and depth of field (defocus blur).
class Camera {
public:
    Camera(Point3 look_from, Point3 look_at, Vec3 vup,
           double vfov_degrees, double aspect_ratio,
           double aperture, double focus_dist) {
        double theta = vfov_degrees * std::numbers::pi / 180.0;
        double h = std::tan(theta / 2);
        double viewport_h = 2.0 * h;
        double viewport_w = aspect_ratio * viewport_h;

        // Orthonormal camera basis.
        w_ = unit_vector(look_from - look_at);
        u_ = unit_vector(cross(vup, w_));
        v_ = cross(w_, u_);

        origin_ = look_from;
        horizontal_ = focus_dist * viewport_w * u_;
        vertical_ = focus_dist * viewport_h * v_;
        lower_left_ = origin_ - horizontal_ / 2 - vertical_ / 2 - focus_dist * w_;
        lens_radius_ = aperture / 2;
    }

    // s, t in [0,1]: horizontal / vertical position on the image plane.
    Ray get_ray(double s, double t) const {
        Vec3 rd = lens_radius_ * random_in_unit_disk();
        Vec3 offset = u_ * rd.x + v_ * rd.y;   // jitter the ray origin across the lens
        return Ray(origin_ + offset,
                   lower_left_ + s * horizontal_ + t * vertical_ - origin_ - offset);
    }

private:
    Point3 origin_, lower_left_;
    Vec3 horizontal_, vertical_, u_, v_, w_;
    double lens_radius_;
};
