#pragma once
#include <memory>
#include <utility>
#include "hittable.h"

class Sphere : public Hittable {
public:
    Sphere(const Point3& center, double radius, std::shared_ptr<Material> m)
        : center_(center), radius_(radius), material_(std::move(m)) {}

    bool hit(const Ray& r, double t_min, double t_max, HitRecord& rec) const override {
        // Solve |origin + t*dir - center|^2 = radius^2, a quadratic in t.
        Vec3 oc = r.origin() - center_;
        double a = r.direction().length_squared();
        double half_b = dot(oc, r.direction());
        double c = oc.length_squared() - radius_ * radius_;
        double disc = half_b * half_b - a * c;
        if (disc < 0) return false;                 // ray misses

        double sqrtd = std::sqrt(disc);
        double root = (-half_b - sqrtd) / a;        // nearest root first
        if (root < t_min || root > t_max) {
            root = (-half_b + sqrtd) / a;           // otherwise try the far root
            if (root < t_min || root > t_max) return false;
        }

        rec.t = root;
        rec.point = r.at(root);
        rec.set_face_normal(r, (rec.point - center_) / radius_);
        rec.material = material_.get();
        return true;
    }

private:
    Point3 center_;
    double radius_;
    std::shared_ptr<Material> material_;
};
